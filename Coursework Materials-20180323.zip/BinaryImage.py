class BinaryImage:

            
       def _determineColorValue(self,b):
            v = 255*b
            return ("#%02x%02x%02x" % (v, v, v))

